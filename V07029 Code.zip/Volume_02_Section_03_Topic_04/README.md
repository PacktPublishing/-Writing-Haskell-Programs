# Writing Haskell Programs

## 2.3.4 "Consuming third-party packages"
