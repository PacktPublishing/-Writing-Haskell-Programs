# Writing Haskell Programs

## 2.3.5 "A brief tour of popular Haskell packages"

### `mutable-vector` project

```
cd mutable-vector
stack build
stack exec mutable-vector
```
