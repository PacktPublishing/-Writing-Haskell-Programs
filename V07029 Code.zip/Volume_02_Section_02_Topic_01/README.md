# Writing Haskell Programs

## 2.2.1 "Introduction to modules"

```
cd example
stack build
```
