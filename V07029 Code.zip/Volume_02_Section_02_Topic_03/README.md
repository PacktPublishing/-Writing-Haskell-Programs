# Writing Haskell Programs

## 2.2.3 "Consuming modules"

### `importing` project

```
cd importing
stack build
```
