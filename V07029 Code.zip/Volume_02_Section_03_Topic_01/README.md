# Writing Haskell Programs

## 2.3.1 "Package repositories"

### `example` project

```
cd example
stack build
```
