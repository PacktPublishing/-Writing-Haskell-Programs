# Writing Haskell Programs

## 2.1.3 "Stack in detail"

This is a sample project with the following features:

* A `description` field in the `.cabal` file
* A library target
* An executable target
* A benchmark target
* Library code is fully marked up with Haddock documentation
* Benchmark code makes two measurements of a simple function
