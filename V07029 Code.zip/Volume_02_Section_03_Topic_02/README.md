# Writing Haskell Programs

## 2.3.2 "Searching"

### `hoogle-example` project

```
cd hoogle-example
stack install hoogle
hoogle generate
hoogle map
```

### `cat-myself` project

```
cd cat-myself
stack build
stack exec cat-myself
```
