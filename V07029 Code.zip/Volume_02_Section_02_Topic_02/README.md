# Writing Haskell Programs

## 2.2.2 "Creating modules"

### `example` project

```
cd example
stack build
```

### `exporting` project

```
cd exporting
stack build
```
