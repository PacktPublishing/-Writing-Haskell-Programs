# Writing Haskell Programs

## 2.1.4 "Stack hints and tips"

```
stack clean
stack build
stack test
stack bench
stack haddock
stack sdist
```
