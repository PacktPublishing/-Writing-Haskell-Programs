# Writing Haskell Programs

## 2.3.3 "Navigating packages"

### `html-parsing` project

```
cd html-parsing
stack build
```

### `error-handling` project

```
cd error-handling
stack build
```
